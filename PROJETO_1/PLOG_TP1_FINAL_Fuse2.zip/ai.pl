:- use_module(library(random)).
:- use_module(library(lists)).
:- [utils].

choose_move(Board, Player, 1, Move) :-
    random_ai(Board, Player, Move).

choose_move(Board, Player, 2, Move) :-
    bot_turn(Board, Player, 5, Move).

choose_move(Board, Player, 3, Move) :-
    bot_turn(Board, Player, 11, Move).

random_ai(Board, Player, NewBoard):-
    valid_moves(Board,Player,ListofMoves),
    length(ListofMoves,Number),
    random(0,Number,RandomNumber),
    nth0(RandomNumber,ListofMoves,NewBoard).

bot_turn(Board, Player, Depth, NewBoard) :-
    nl, write('Player '), write(Player), write(' turn:'),nl,
    valid_moves(Board, Player, Moves),
    get_winning_move(Moves, Player, WinningMove),
    NewBoard = WinningMove, !.
  
bot_turn(Board, Player, Depth, NewBoard) :-
    nl, write('Player '), write(Player), write(' turn:'),nl,
    valid_moves(Board, Player, Moves),
    minmax(Depth, Player, Board, NewBoard), !.


minimax( Pos, Player, BestSucc, Val)  :-
    moves( Pos, Player, PosList), !,               % Legal moves in Pos produce PosList
    best( PosList, Player, BestSucc, Val);
    staticval( Pos, Val).                           % Pos has no successors: evaluate statically 
  
best([Pos], Player, Pos, Val)  :-
    minimax( Pos, Player, _, Val), !.
  
best([Pos1 | PosList], BestPos, BestVal)  :-
    minimax( Pos1, _, Val1),
    best( PosList, Pos2, Val2),
    betterof( Pos1, Val1, Pos2, Val2, BestPos, BestVal).
  
betterof( Pos0, Val0, Pos1, Val1, Pos0, Val0)  :-        % Pos0 better than Pos1
    min_to_move( Pos0),                                    % MIN to move in Pos0
    Val0 > Val1, !                                         % MAX prefers the greater value
    ;
    max_to_move( Pos0),                                    % MAX to move in Pos0
    Val0 < Val1, !.                                % MIN prefers the lesser value 
  
betterof( Pos0, Val0, Pos1, Val1, Pos1, Val1).    



%RETURNS IF THERE IS A WINNING MOVE 
get_winning_move([], _, _) :- !, fail.

get_winning_move([Head|NextPlays], Player, Board) :-
    get_player_piece(Player, Piece),
    game_over(Head, Piece), 
    Board = Head.
    
get_winning_move([Head|NextPlays], Player, Board) :-
    get_player_piece(Player, Piece),
    get_winning_move(NextPlays, Board).